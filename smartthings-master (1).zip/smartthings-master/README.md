# smartthings

Devices and SmartApps for Samsung Smartthings HUB

### devices
- symfonisk.groovy
  Device Handler for Ikea Symfonisk Controller

### smartapps
- sonos-remote-control.groovy
  SmartApp for controlling Sonos devices with Ikea Symfonisk Controller
- light-control.groovy
  SmartApp for controlling light bulb with Ikea Symfonisk Controller
